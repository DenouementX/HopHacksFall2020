import React from 'react';
import { channels } from '../shared/constants';
import styles from './App.css';

const { ipcRenderer } = window;

class App extends React.Component {
  render() {
    document.addEventListener("keydown", e => {
      switch(e.key) {
        case "Escape":
          ipcRenderer.send(channels.QUIT_INFO);
          break;
        default: break;
      }
    });

    return (
      <div className = "body">
        <div className="Detection-settings">
          <p className="Detection-text"> Detection Settings </p>

          <p className="Left-text1"> Mute on unknown voice </p>
          <div className="Slider-box1">
            <label className="switch">
              <input type="checkbox"/>
              <span class="slider round"></span>
            </label>
          </div>

          <p className="Left-text2"> Disable video on unknown person </p>
          <div className="Slider-box2">
            <label className="switch">
              <input type="checkbox"/>
              <span class="slider round"></span>
            </label>
          </div>
        </div>

        <div className="Gesture-bindings">
          <p className="Gesture-text"> Gesture Bindings </p>

          <div className="Selector">
            <label for="t-up">Thumbs Up: </label>
            <select name="t-up" id="t-up">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="t-down">Thumbs Down: </label>
            <select name="t-down" id="t-down">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="s-up">Speed Up: </label>
            <select name="s-up" id="s-up">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="s-down">Slow Down: </label>
            <select name="s-down" id="s-down">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="r-hand">Raise Hand: </label>
            <select name="r-hand" id="r-hand">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="clap">Clap: </label>
            <select name="clap" id="clap">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="tada">Tada: </label>
            <select name="tada" id="tada">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="heart">Heart: </label>
            <select name="heart" id="heart">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="laugh">Laughing: </label>
            <select name="laugh" id="laugh">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>

          <div className="Selector">
            <label for="shock">Open-mouth: </label>
            <select name="shock" id="shock">
              <option value="placeholder">PLACEHOLDER</option>
            </select>
          </div>
        </div>

        <div className="Camera-box">
          <p className="Camera-text"> Live Camera Feed </p>
        </div>
      </div>
    );
  }
}

export default App;
