module.exports = {
    channels: {
        APP_INFO: 'app_info',
        QUIT_INFO: 'quit_info',
    },
};